#include <algorithm>

#include <hyprland/src/Compositor.hpp>
#include <hyprland/src/Window.hpp>
#include <hyprland/src/helpers/Vector2D.hpp>

#include "globals.hpp"
#include "log.hpp"
#include "Slider.hpp"

void SWindow::applyGeom() {
    w->m_vPosition = Vector2D(geom.x, geom.y);
    w->m_vSize = Vector2D(geom.w, geom.h);

    w->m_vRealPosition = w->m_vPosition;
    w->m_vRealSize = w->m_vSize;
}

bool Slider::isActive(CWindow* w) {
    return active && (w == active->w);
}

bool Slider::hasWindow(CWindow* w) {
    if (active->w == w)
        return true;

    for (auto lw : lefts) {
        if (lw.w == w)
            return true;
    }

    for (auto rw : rights) {
        if (rw.w == w)
            return true;
    }
    return false;
}

bool Slider::hasWorkspace(int ws) {
    return workspace == ws;
}

void Slider::addActiveWindow(CWindow* w) {
    if (active) {
        auto old_active = active;

        lefts.push_front(active.value());
        active = SWindow(w);
        active->geom.setPos(old_active->geom.x + old_active->geom.w, maxsz.y);
    } else {
        active = SWindow(w);
    }

    recalculateSizePos();
}

void Slider::removeWindow(CWindow* w) {
    if (w == active->w) {
        if (!lefts.empty()) {
            active = lefts.front();
            lefts.pop_front();
        } else if (!rights.empty()) {
            active = rights.front();
            rights.pop_front();
        } else {
            active.reset();
        }
    } else {
        lefts.remove_if([w](auto l) { return l.w == w; });
        rights.remove_if([w](auto r) { return r.w == w; });
    }

    recalculateSizePos();
}

void Slider::focusWindow(CWindow* w) {
    if (w == active->w) { // probably shouldn't happen, but who knows?
        return;
    }

    auto it = std::find_if(lefts.begin(), lefts.end(), [w](auto l) { return l.w == w; });
    if (it != lefts.end()) {
        while (active->w != w) {
            moveFocusLeft();
        }
    } else {
        it = std::find_if(rights.begin(), rights.end(), [w](auto r) { return r.w == w; });
        if (it != rights.end()) {
            while (active->w != w) {
                moveFocusRight();
            }
        }
    }

    recalculateSizePos();
}

void Slider::resizeActiveWindow() {
    if (!active || active->fs)
        return;

    switch (active->sz) {
        case SWindowSize::OneThird: active->sz = SWindowSize::OneHalf; break;
        case SWindowSize::OneHalf: active->sz = SWindowSize::TwoThirds; break;
        case SWindowSize::TwoThirds: active->sz = SWindowSize::OneThird; break;
    }

    recalculateSizePos();
}

void Slider::centerActiveWindow() {
    if (!active || active->fs)
        return;

    switch (active->sz) {
        case SWindowSize::OneThird: active->geom.setPos(maxsz.x + maxsz.w / 3, maxsz.y); break;
        case SWindowSize::OneHalf: active->geom.setPos(maxsz.x + maxsz.w / 4, maxsz.y); break;
        case SWindowSize::TwoThirds: active->geom.setPos(maxsz.x + maxsz.w / 6, maxsz.y); break;
    }

    recalculateSizePos();
}

void Slider::toggleMaximizeActiveWindow() {
    if (!active)
        return;

    active->fs = !active->fs;
    if (active->fs) {
        active->geom.setSize(maxsz.w, maxsz.h);

        recalculateSizePos();
    } else {
        switch (active->sz) {
            case SWindowSize::OneThird: active->geom.setSize(maxsz.w / 3, maxsz.h); break;
            case SWindowSize::OneHalf: active->geom.setSize(maxsz.w / 2, maxsz.h); break;
            case SWindowSize::TwoThirds: active->geom.setSize(2 * maxsz.w / 3, maxsz.h); break;
        }

        centerActiveWindow();
    }
}

void Slider::toggleFullscreenActiveWindow() {
    if (!active)
        return;

    const auto PWORKSPACE = g_pCompositor->getWorkspaceByID(active->w->m_iWorkspaceID);

    active->w->m_bIsFullscreen = !active->w->m_bIsFullscreen;
    PWORKSPACE->m_bHasFullscreenWindow = active->w->m_bIsFullscreen;
    if (active->w->m_bIsFullscreen) {
        slidr_log(INFO, "activate fullscreen");
        active->geom = SBox(fullsz.x, fullsz.y, fullsz.w, fullsz.h);

        active->applyGeom();
    } else {
        slidr_log(INFO, "de-activate fullscreen");
        active->geom.setPos(maxsz.x, maxsz.y);

        centerActiveWindow();
    }
}

void Slider::moveActiveWindow(Direction dir) {
    switch (dir) {
        case Direction::Right:
            if (rights.size() > 0) {
                auto rw = rights.front();
                lefts.push_front(rw);
                rights.pop_front();

                auto tmp = rw.geom;
                rw.geom.setPos(active->geom.x, active->geom.y);
                active->geom.setPos(tmp.x, tmp.y);
            }
            break;
        case Direction::Left:
            if (lefts.size() > 0) {
                auto lw = lefts.front();
                rights.push_front(lw);
                lefts.pop_front();

                auto tmp = lw.geom;
                lw.geom.setPos(active->geom.x, active->geom.y);
                active->geom.setPos(tmp.x, tmp.y);
            }
            break;
    }

    recalculateSizePos();
}

void Slider::moveFocus(Direction dir) {
    switch (dir) {
        case Direction::Left: moveFocusLeft(); break;
        case Direction::Right: moveFocusRight(); break;
        case Direction::Center: return;
    }

    recalculateSizePos();
}

void Slider::alignWindow(Direction dir) {
    if (!active || active->fs)
        return;

    switch (dir) {
        case Direction::Center: centerActiveWindow(); break;
        case Direction::Left: active->geom.setPos(maxsz.x, maxsz.y); break;
        case Direction::Right: active->geom.setPos(maxsz.x + maxsz.w - active->geom.w, maxsz.y);break;
    }

    recalculateSizePos();
}

void Slider::recalculateSizePos() {
    if (!active)
        return;

    // set geom.{w,h} for all windows
    switch (active->sz) {
        case SWindowSize::OneThird: active->geom.setSize(maxsz.w / 3, maxsz.h); break;
        case SWindowSize::OneHalf: active->geom.setSize(maxsz.w / 2, maxsz.h); break;
        case SWindowSize::TwoThirds: active->geom.setSize(2 * maxsz.w / 3, maxsz.h); break;
    }
    if (active->fs)
        active->geom.setSize(maxsz.w, maxsz.h);
    for (auto lw : lefts) {
        switch (lw.sz) {
            case SWindowSize::OneThird: lw.geom.setSize(maxsz.w / 3, maxsz.h); break;
            case SWindowSize::OneHalf: lw.geom.setSize(maxsz.w / 2, maxsz.h); break;
            case SWindowSize::TwoThirds: lw.geom.setSize(2 * maxsz.w / 3, maxsz.h); break;
        }
        if (lw.fs)
            lw.geom.setSize(maxsz.w, maxsz.h);
    }
    for (auto rw : rights) {
        switch (rw.sz) {
            case SWindowSize::OneThird: rw.geom.setSize(maxsz.w / 3, maxsz.h); break;
            case SWindowSize::OneHalf: rw.geom.setSize(maxsz.w / 2, maxsz.h); break;
            case SWindowSize::TwoThirds: rw.geom.setSize(2 * maxsz.w / 3, maxsz.h); break;
        }
        if (rw.fs)
            rw.geom.setSize(maxsz.w, maxsz.h);
    }

    // set geom.{x,h} for all windows
    // 1. active visible
    auto lefts_width = std::ranges::fold_left(lefts, 0, [](auto acc, auto lw) { return acc + lw.geom.w; });
    auto rights_width = std::ranges::fold_left(rights, 0, [](auto acc, auto rw) { return acc + rw.geom.w; });

    if (lefts_width + active->geom.w + rights_width <= maxsz.w) {
        auto border = (maxsz.w - lefts_width - active->geom.w - rights_width) / 2.;

        active->geom.setPos(maxsz.x + border + lefts_width, maxsz.y);
    } else {
        auto left_edge = active->geom.x - lefts_width - maxsz.x;
        auto right_edge = (maxsz.x + maxsz.w) - (active->geom.x + active->geom.w + rights_width);

        if (left_edge > 0) {
            active->geom.setPos(maxsz.x + lefts_width, maxsz.y);
        } else if (right_edge > 0) {
            active->geom.setPos(maxsz.x + maxsz.w - rights_width - active->geom.w, maxsz.y);
        } else if (active->geom.x < maxsz.x) {
            active->geom.setPos(maxsz.x, maxsz.y);
        } else if (active->geom.x + active->geom.w > maxsz.w) {
            active->geom.setPos(maxsz.x + maxsz.w - active->geom.w, maxsz.y);
        }
    }
    // 2. adjust positions of windows to the left
    auto sw = *active;
    for (auto& lw : lefts) {
        lw.geom.setPos(sw.geom.x - lw.geom.w, maxsz.y);
        sw = lw;
    }
    // 3. adjust positions of windows to the right
    sw = *active;
    for (auto& rw : rights) {
        rw.geom.setPos(sw.geom.x + sw.geom.w, maxsz.y);
        sw = rw;
    }

    // apply geom
    active->applyGeom();
    for (auto lw : lefts) {
        lw.applyGeom();
    }
    for (auto rw : rights) {
        rw.applyGeom();
    }
}

CWindow* Slider::getActiveWindow() {
    if (!active)
        return nullptr;
    else
        return active->w;
}

void Slider::moveFocusLeft() {
    if (lefts.size() == 0)
        return;

    rights.push_front(*active);
    active = lefts.front();
    lefts.pop_front();
}

void Slider::moveFocusRight() {
    if (rights.size() == 0)
        return;

    lefts.push_front(*active);
    active = rights.front();
    rights.pop_front();
}
