#pragma once

#include <hyprland/src/helpers/Vector2D.hpp>
#include <optional>

#include <hyprland/src/Window.hpp>

enum class SWindowSize {
    OneThird,
    OneHalf,
    TwoThirds
};

enum class Direction {
    Right,
    Left,
    Center
};

struct SBox {
    SBox() : x(0), y(0), w(0), h(0) {}
    SBox(double x_, double y_, double w_, double h_) : x(x_), y(y_), w(w_), h(h_) {}
    SBox(Vector2D pos, Vector2D size) : x(pos.x), y(pos.y), w(size.x), h(size.y) {}

    void setSize(double w_, double h_) {
        w = w_;
        h = h_;
    }
    void move(double dx, double dy) {
        x += dx;
        y += dy;
    }
    void setPos(double x_, double y_) {
        x = x_;
        y = y_;
    }

    double x, y, w, h;
};

struct SWindow {
    SWindow(CWindow* w0) : w(w0), sz(SWindowSize::OneThird), fs(false) {}

    void applyGeom();

    CWindow* w;
    SWindowSize sz;
    bool fs;
    SBox geom;
};

class Slider {
  public:
    Slider(int workspace_, CWindow* w_, SBox fullsz_, SBox maxsz_) : workspace(workspace_), fullsz(fullsz_), maxsz(maxsz_) {
        addActiveWindow(w_);
    }

    bool isActive(CWindow* w);
    bool hasWindow(CWindow*);
    bool hasWorkspace(int);
    void addActiveWindow(CWindow*);
    void removeWindow(CWindow*);
    void focusWindow(CWindow*);
    void resizeActiveWindow();
    void centerActiveWindow();
    void toggleMaximizeActiveWindow();
    void toggleFullscreenActiveWindow();
    void moveActiveWindow(Direction);
    void moveFocus(Direction);
    void alignWindow(Direction);
    void recalculateSizePos();

    CWindow* getActiveWindow();
    void setSizes(SBox fullsz_, SBox maxsz_) {
        fullsz = fullsz_;
        maxsz = maxsz_;
    }

  private:
    void moveFocusLeft();
    void moveFocusRight();

    int workspace;
    SBox fullsz, maxsz;
    std::optional<SWindow> active;
    std::list<SWindow> lefts;
    std::list<SWindow> rights;

    friend struct std::formatter<Slider>;
};

template <>
struct std::formatter<SWindowSize> {
    constexpr auto parse(std::format_parse_context& ctx) {
        return ctx.begin();
    }

    auto format(const SWindowSize& sz, std::format_context& ctx) const {
        switch (sz) {
            case SWindowSize::OneThird: return std::format_to(ctx.out(), "SWindowSize: {}", "one-third");
            case SWindowSize::OneHalf: return std::format_to(ctx.out(), "SWindowSize: {}", "one-half");
            case SWindowSize::TwoThirds: return std::format_to(ctx.out(), "SWindowSize: {}", "two-thirds");
        }
        return std::format_to(ctx.out(), "{}", "[SWindowSize: bad value]");
    }
};

template <>
struct std::formatter<SWindow> {
    constexpr auto parse(std::format_parse_context& ctx) {
        return ctx.begin();
    }

    auto format(const SWindow& w, std::format_context& ctx) const {
        return std::format_to(ctx.out(), "SWindow: w:{} sz:{} fs:{}", w.w, w.sz, w.fs);
    }
};

template <>
struct std::formatter<SBox> {
    constexpr auto parse(std::format_parse_context& ctx) {
        return ctx.begin();
    }

    auto format(const SBox& b, std::format_context& ctx) const {
        return std::format_to(ctx.out(), "Sbox: x:{} y:{} w:{} h:{}", b.x, b.y, b.w, b.h);
    }
};

template <>
struct std::formatter<Direction> {
    constexpr auto parse(std::format_parse_context& ctx) {
        return ctx.begin();
    }

    auto format(const Direction& dir, std::format_context& ctx) const {
        switch (dir) {
            case Direction::Left: return std::format_to(ctx.out(), "Direction:{}", "left");
            case Direction::Right: return std::format_to(ctx.out(), "Direction:{}", "right");
        }
        return std::format_to(ctx.out(), "{}", "[SWindowSize: bad value]");
    }
};

template <>
struct std::formatter<Slider> {
    constexpr auto parse(std::format_parse_context& ctx) {
        return ctx.begin();
    }

    auto format(const Slider& s, std::format_context& ctx) const {
        return std::format_to(ctx.out(), "[Slider: active:a lefts:{} rights:{}]", s.lefts.size(), s.rights.size());
    }
};
