#pragma once

namespace dispatchers {
    void addDispatchers();
}
