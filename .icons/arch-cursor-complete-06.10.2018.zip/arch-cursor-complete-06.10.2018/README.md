### Arch Cursor Complete theme
This X11 cursor theme is based on [Arch Cursor Simple](https://www.gnome-look.org/content/show.php/Arch+Cursor+Theme+\(simple\)?content=135902), completed with custom-made resize cursors that were missing.
Original cursors I deemed unappealing in the original theme, such as 'text' and 'crosshair', were overhauled.
Tested under Gnome and i3, and Sway on Wayland.

Feedback welcome.

#### Installation
Put ArchCursorComplete folder into ~/.icons directory. For system-wide installation, put it in /usr/share/icons/ instead.
For Arch Linux users, install xcursors-arch-cursor-complete package from the AUR.
